package com.cg.iter.demo1.4th;

public interface EmployeeService {
public Employee getDetails(int empId);
}
